<?php
header("Access-Control-Allow-Origin:http://localhost:3000");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, X-Requested-With");

require_once('connect.php');
// Create connection
$conn = connectDB();
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

/**********************************************************************************************************************************/
if(isset($_GET['nameReq']) and isset($_GET['did'])){
    $did = $_GET['did'];
    $sql = "SELECT dealer_name FROM `car_dealer` where car_dealer_id=$did and deleted = 0";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result)) {
        $cr=0;
        while($row = mysqli_fetch_assoc($result)) {
            $dealers[$cr]['dealer_name']=$row['dealer_name'];
        }
    
        echo json_encode($dealers);
    } else {
        echo "0 results";
    }
}
else if(isset($_GET['car'])){
    $sql = "SELECT car_dealer_id, dealer_name FROM `car_dealer` where deleted = 0";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result)) {
        $cr=0;
        while($row = mysqli_fetch_assoc($result)) {
            $dealers[$cr]['car_dealer_id']=$row['car_dealer_id'];
            $dealers[$cr]['dealer_name']=$row['dealer_name'];
            $cr++;
        }
    
        echo json_encode($dealers);
    } else {
        echo "0 results";
    }

}//get closing

else if(isset($_GET['did'])){
    $did=$_GET['did'];
    $sql = "SELECT * FROM `car_dealer` where car_dealer_id=$did AND deleted = 0";
    $result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result)==1) {
    $cr=0;
    while($row = mysqli_fetch_assoc($result)) {
        $dealers[$cr]['car_dealer_id']=$row['car_dealer_id'];
        $dealers[$cr]['dealer_name']=$row['dealer_name'];
        $dealers[$cr]['dealer_company_name']=$row['dealer_company_name'];
        $dealers[$cr]['dealer_company_address']=$row['dealer_company_address'];
        $dealers[$cr]['dealer_number']=$row['dealer_number'];
        $dealers[$cr]['dealer_email']=$row['dealer_email'];
    }
    
    echo json_encode($dealers);
} else {
    echo "0 results";
}

}

else{
    $sql = "SELECT * FROM `car_dealer` where deleted = 0";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result)) {
    $cr=0;
    while($row = mysqli_fetch_assoc($result)) {
        $dealers[$cr]['car_dealer_id']=$row['car_dealer_id'];
        $dealers[$cr]['dealer_name']=$row['dealer_name'];
        $dealers[$cr]['dealer_company_name']=$row['dealer_company_name'];
        $dealers[$cr]['dealer_company_address']=$row['dealer_company_address'];
        $dealers[$cr]['dealer_number']=$row['dealer_number'];
        $dealers[$cr]['dealer_email']=$row['dealer_email'];
        $cr++;
    }
    
    echo json_encode($dealers);
} else {
    echo "0 results";
}
}
$conn->close();
?>