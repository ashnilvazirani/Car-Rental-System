<?php
header("Access-Control-Allow-Origin:http://localhost:3000");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, X-Requested-With");
//require_once('headers_define.php');
require_once('connect.php');
// Create connection
$conn = connectDB();
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
    $sql = "SELECT * FROM `car_request` WHERE request_id NOT IN (SELECT request_id from booked_cars)";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result)) {
    // output data of each row
    $cr=0;
    while($row = mysqli_fetch_assoc($result)) {
        $req[$cr]['request_id']=$row['request_id'];
        $req[$cr]['car_id']=$row['car_id'];
        $req[$cr]['customer_name']=$row['customer_name'];
        $req[$cr]['customer_email']=$row['customer_email'];
        $req[$cr]['customer_number']=$row['customer_number'];
        $req[$cr]['pickup_address']=$row['pickup_address'];
        $req[$cr]['destination_address']=$row['destination_address'];
        $req[$cr]['trip_type']=$row['trip_type'];
        $req[$cr]['pickup_date']=$row['pickup_date'];
        $req[$cr]['drop_date']=$row['drop_date'];
        $req[$cr]['comments']=$row['comments'];
        $cr++;
    }
    
    echo json_encode($req);
} else {
    echo "0 results";
}

$conn->close();
?>
