<?php
header("Access-Control-Allow-Origin:http://localhost:3000");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, X-Requested-With");

//require_once('headers_define.php');
require_once("connect.php");

$post_data = file_get_contents("php://input");
if(isset($post_data) && !empty($post_data)){
    $conn = connectDB();
    $req = json_decode($post_data);
    if(strcmp("car_dealer",$req->requestor)==0){
        echo "INSIDE TO DELETE A DEALER";
        $car_dealer_id = $req->car_dealer_id;
        $sql = "UPDATE car_dealer SET deleted = 1 WHERE car_dealer_id = $car_dealer_id";
        
        if (mysqli_query($conn, $sql)) {
            echo "Record updated successfully";
        } else {
            echo "Error updating record: " . $conn->error;
        }
        
    }else if(strcmp("enquiry",$req->requestor)==0){
        echo "INSIDE TO DELETE A DEALER";
        $eid = $req->eid;
        $sql = "UPDATE enquiry SET deleted = 1 WHERE eid = $eid";
        
        if (mysqli_query($conn, $sql)) {
            echo "Record updated successfully";
        } else {
            echo "Error updating record: " . $conn->error;
        }
        
    }else if(strcmp("car_request",$req->requestor)==0){
        echo "INSIDE TO DELETE A DEALER";
        $request_id = $req->request_id;
        $sql = "DELETE FROM `car_request` WHERE `car_request`.`request_id` = $request_id";
        
        if (mysqli_query($conn, $sql)) {
            echo "Record Deleted successfully";
        } else {
            echo "Error updating record: " . $conn->error;
        }
        
    }else if(strcmp("cars",$req->requestor)==0){
        echo "INSIDE TO DELETE A DEALER";
        $car_id = $req->car_id;
        $sql = "UPDATE cars SET deleted = 1 WHERE car_id = $car_id";
        
        if (mysqli_query($conn, $sql)) {
            echo "Record updated successfully";
        } else {
            echo "Error updating record: " . $conn->error;
        }
    }else if(1){
        echo "TP";
    }
    $conn->close();
}//isset closin
?>