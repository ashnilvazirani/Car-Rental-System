<?php
header("Access-Control-Allow-Origin:http://localhost:3000");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, X-Requested-With");
//require_once('headers_define.php');
require_once('connect.php');
// Create connection
$conn = connectDB();
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
    $sql = "SELECT * FROM `cars` WHERE car_id IN (SELECT car_id from booked_cars where status=0)";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result)) {
    // output data of each row
    $cr=0;
    while($row = mysqli_fetch_assoc($result)) {
        $cars[$cr]['car_id']=$row['car_id'];
        $cars[$cr]['car_brand']=$row['car_brand'];
        $cars[$cr]['car_name']=$row['car_name'];
        $cars[$cr]['car_number']=$row['car_number'];
        $cars[$cr]['car_model']=$row['car_model'];
        $cars[$cr]['car_description']=$row['car_description'];
        $cars[$cr]['car_image']=$row['car_image'];
        $cars[$cr]['car_charges']=$row['car_charges'];
        $cars[$cr]['car_dealer_id']=$row['car_dealer_id'];
        $cr++;
    }   
    echo json_encode($cars);
} else {
    echo "0 results";
}
$conn->close();
?>
