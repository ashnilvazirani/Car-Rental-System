<?php

header("Access-Control-Allow-Origin:http://localhost:3000");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, X-Requested-With");

require_once("connect.php");

$post_data = file_get_contents("php://input");

if(isset($post_data) && !empty($post_data)){
    $conn = connectDB();
    $req = json_decode($post_data);
    if(strcmp("cars",$req->requestor)==0){
            echo "inside car insertion";
            if(count(json_decode($post_data, true))>1 and !isset($_GET['cid'])){
                echo "inside count";
                $car_brand = $req->car_brand;
                $car_name = $req->car_name;
                $car_number = $req->car_number;
                $car_model = $req->car_model;
                $car_description = $req->car_description;
                $car_image = $req->car_image;
                $car_charges = $req->car_charges;
                $car_dealer_id = $req->car_dealer_id;
                
            $sql = "INSERT INTO `cars` (`car_brand`, `car_name`, `car_number`, `car_model`, `car_description`, `car_image`, `car_charges`, `car_dealer_id`, `status`, `deleted`) VALUES ('$car_brand', '$car_name', '$car_model', '$car_model', '$car_description', '$car_image', '$car_charges', '$car_dealer_id', 0, 0);";
            if ($conn->query($sql) === TRUE) {
                echo "New CAR INSERTED successfully";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        }//count    
    }//requestor
    $conn->close();
}//isset

?>