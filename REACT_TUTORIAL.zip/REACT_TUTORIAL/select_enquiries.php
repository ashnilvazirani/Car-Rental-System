<?php
header("Access-Control-Allow-Origin:http://localhost:3000");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, X-Requested-With");
//require_once('headers_define.php');
require_once('connect.php');
// Create connection
$conn = connectDB();
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM `enquiry` WHERE deleted = 0";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result)) {
    // output data of each row
    $cr=0;
    while($row = mysqli_fetch_assoc($result)) {
//        echo "id: " . $row["car_dealer_id"]. " - Name: " . $row["dealer_name"]. " CompanyName: " . $row["dealer_company_name"]. "<br>";
        $enquiries[$cr]['eid']=$row['eid'];
        $enquiries[$cr]['name']=$row['name'];
        $enquiries[$cr]['email']=$row['email'];
        $enquiries[$cr]['mobile']=$row['mobile'];
        $enquiries[$cr]['comments']=$row['comments'];
        $cr++;
    }
    
    echo json_encode($enquiries);
} else {
    echo "0 results";
}
$conn->close();
?>