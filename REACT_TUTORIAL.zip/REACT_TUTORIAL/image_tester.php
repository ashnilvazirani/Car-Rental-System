<?php
header("Access-Control-Allow-Origin:http://localhost:3000");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, X-Requested-With");


$post_data = file_get_contents("php://input");

$request = json_decode($post_data);
    
//$img = str_replace('', '', $request->fileName);
//$img = str_replace(' ','+',$img);
$path1="C:/Users/ashni/Desktop/REACT/tutorial/image-content/";
if(isset($_GET['car'])){
    $path="car_image/";
}else{
    $path="dealer_identity/";
}
$path1=$path1.$path;
echo move_uploaded_file(base64_decode($request->fileName),$path."".$request->nameOfImage);
echo file_put_contents($path1."".$request->nameOfImage, base64_decode($request->fileName)); 
?>