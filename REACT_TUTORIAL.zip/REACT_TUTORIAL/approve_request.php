<?php

header("Access-Control-Allow-Origin:http://localhost:3000");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, X-Requested-With");

require_once("connect.php");

$post_data = file_get_contents("php://input");
$conn = connectDB();
    
if(isset($post_data) && !empty($post_data)){
    $req = json_decode($post_data);
    if(strcmp("car_request",$req->requestor)==0){
            echo "inside car_request insertion";
            if(count(json_decode($post_data, true))>1){
                echo "inside ";
                $request_id = $req->request_id;
                $car_id = $req->car_id;
                
            $sql = "INSERT INTO `booked_cars` (`request_id`, `car_id`, `status`) VALUES ('$request_id', '$car_id', 0);";
            if ($conn->query($sql) === TRUE) {
                echo "CAR BOOKING DONE SUCCESSFULLY";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        }//count    
    }//requestor
    
}//isset

//status = 0-> car is assigned for the trip,
//status = 1-> trip is complete
$q="UPDATE booked_cars SET status = 1 WHERE car_id IN (select car_id from car_request where request_id in (SELECT request_id from car_request where drop_date < CURRENT_DATE))";
if ($conn->query($q) === TRUE) {
                echo "CAR RIDE DONE SUCCESSFULLY";
            } else {
                echo "Error: " . $q . "<br>" . $conn->error;
            }
$conn->close();
?>
