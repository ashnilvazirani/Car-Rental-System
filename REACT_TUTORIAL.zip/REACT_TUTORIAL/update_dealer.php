<?php
header("Access-Control-Allow-Origin:http://localhost:3000");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, X-Requested-With");

require_once("connect.php");
echo $_GET['did'];  
$post_data = file_get_contents("php://input");
if(isset($post_data) && !empty($post_data)){
    $conn = connectDB();
    $req = json_decode($post_data);
    if(strcmp("car_dealer",$req->requestor)==0){
            echo "inside dealer";
            if(count(json_decode($post_data, true))>=6 and isset($_GET['did'])){
            $did = $_GET['did'];
            echo "inside update dealer";
            $dealer_name = $req->dealer_name;
            $dealer_company_name = $req->dealer_company_name;
            $dealer_company_address = $req->dealer_company_address;
            $dealer_number = $req->dealer_number;
            $dealer_email = $req->dealer_email;
            $dealer_identity = $req->dealer_identity;
            $sql = "UPDATE car_dealer SET dealer_name = '$dealer_name', dealer_company_name='$dealer_company_name', dealer_company_address='$dealer_company_address', dealer_number='$dealer_number', dealer_email='$dealer_email', dealer_identity='$dealer_identity' WHERE car_dealer_id = $did";
            if ($conn->query($sql) === TRUE) {
                echo "New record created successfully";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        }
    }//strcmp closing
}
?>