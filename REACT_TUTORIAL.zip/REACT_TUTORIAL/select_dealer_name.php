<?php
header("Access-Control-Allow-Origin:http://localhost:3000");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, X-Requested-With");

require_once('connect.php');
// Create connection
$conn = connectDB();
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if(isset($_GET['namereq']) and isset($_GET['did'])){
    $did = $_GET['did'];
    $sql = "SELECT dealer_name FROM `car_dealer` where car_dealer_id=$did and deleted = 0";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result)) {
        $cr=0;
        while($row = mysqli_fetch_assoc($result)) {
            $dealers[$cr]['dealer_name']=$row['dealer_name'];
        }
    
        echo json_encode($dealers);
    } else {
        echo "0 results";
    }
}

?>