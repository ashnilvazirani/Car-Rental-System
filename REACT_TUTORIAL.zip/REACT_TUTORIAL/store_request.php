<?php

header("Access-Control-Allow-Origin:http://localhost:3000");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, X-Requested-With");

require_once("connect.php");

$post_data = file_get_contents("php://input");

if(isset($post_data) && !empty($post_data)){
    $conn = connectDB();
    $req = json_decode($post_data);
    if(strcmp("car_request",$req->requestor)==0){
            echo "inside car insertion";
            if(count(json_decode($post_data, true))>1){
                echo "inside count";
                $car_id = $req->car_id;
                $customer_name = $req->customer_name;
                $customer_email = $req->customer_email;
                $customer_number = $req->customer_number;
                $pickup_address = $req->pickup_address;
                $destination_address = $req->destination_address;
                $trip_type= $req->trip_type;
                $pickup_date = $req->pickup_date;
                $drop_date = $req->drop_date;
                $comments = $req->comments;
                
            $sql = "INSERT INTO `car_request` (`car_id`, `customer_name`, `customer_email`, `customer_number`, `pickup_address`, `destination_address`, `trip_type`, `pickup_date`, `drop_date`, `comments`, `status`) VALUES ('$car_id', '$customer_name', '$customer_email', '$customer_number', '$pickup_address', '$destination_address', '$trip_type', '$pickup_date', '$drop_date', '$comments', '0')";
                
            if ($conn->query($sql) === TRUE) {
                echo "NEW CAR REQUEST SENT successfully";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        }//count    
    }//requestor
    $conn->close();
}//isset

?>