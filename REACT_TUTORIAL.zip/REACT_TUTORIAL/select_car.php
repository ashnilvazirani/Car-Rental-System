    <?php
    header("Access-Control-Allow-Origin:http://localhost:3000");
    header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, X-Requested-With");
    //require_once('headers_define.php');
    require_once('connect.php');
    // Create connection
    $conn = connectDB();
    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    
 if(isset($_GET['cid']) and isset($_GET['carName'])){
    $cid = $_GET['cid'];
    $sql = "SELECT * FROM `cars` WHERE car_id = $cid AND deleted = 0";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result)>0) {
    // output data of each row
    $cr=0;
    while($row = mysqli_fetch_assoc($result)) {
//        $cars[$cr]['car_id']=$row['car_id'];
        $cars[$cr]['car_brand']=$row['car_brand'];
//        $cars[$cr]['car_name']=$row['car_name'];
//        $cars[$cr]['car_number']=$row['car_number'];
//        $cars[$cr]['car_model']=$row['car_model'];
//        $cars[$cr]['car_description']=$row['car_description'];
//        $cars[$cr]['car_image']=$row['car_image'];
//        $cars[$cr]['car_charges']=$row['car_charges'];
//        $cars[$cr]['car_dealer_id']=$row['car_dealer_id'];
//        
    }
    
    echo json_encode($cars);
}
}else if(isset($_GET['cid']) and isset($_GET['date'])){
    $cid = $_GET['cid'];
    $sql = "SELECT pickup_date FROM `car_request` WHERE car_id = $cid ";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result)) {
    // output data of each row
    $cr=0;
    while($row = mysqli_fetch_assoc($result)) {
        $cars[$cr]['pickup_date']=$row['pickup_date'];
    }
    
    echo json_encode($cars);
}else{
        echo json_encode(0);
    }

}//cid isset if closing
else if(isset($_GET['cid'])){
        $cid = $_GET['cid'];
        $sql = "SELECT * FROM `cars` WHERE car_id = $cid AND deleted = 0";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result)) {
        // output data of each row
        $cr=0;
        while($row = mysqli_fetch_assoc($result)) {
            $cars[$cr]['car_id']=$row['car_id'];
            $cars[$cr]['car_brand']=$row['car_brand'];
            $cars[$cr]['car_name']=$row['car_name'];
            $cars[$cr]['car_number']=$row['car_number'];
            $cars[$cr]['car_model']=$row['car_model'];
            $cars[$cr]['car_description']=$row['car_description'];
            $cars[$cr]['car_image']=$row['car_image'];
            $cars[$cr]['car_charges']=$row['car_charges'];
            $cars[$cr]['car_dealer_id']=$row['car_dealer_id'];

        }

        echo json_encode($cars);
    } else {
        echo "0 results";
    }

    }
else{
    $sql = "SELECT * FROM `cars` WHERE deleted = 0";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result)) {
    // output data of each row
    $cr=0;
    while($row = mysqli_fetch_assoc($result)) {
        $cars[$cr]['car_id']=$row['car_id'];
        $cars[$cr]['car_brand']=$row['car_brand'];
        $cars[$cr]['car_name']=$row['car_name'];
        $cars[$cr]['car_number']=$row['car_number'];
        $cars[$cr]['car_model']=$row['car_model'];
        $cars[$cr]['car_description']=$row['car_description'];
        $cars[$cr]['car_image']=$row['car_image'];
        $cars[$cr]['car_charges']=$row['car_charges'];
        $cars[$cr]['car_dealer_id']=$row['car_dealer_id'];
        $cars[$cr]['status']=$row['status'];
        $cars[$cr]['deleted']=$row['deleted'];
        $cr++;
    }
    
    echo json_encode($cars);
} else {
    echo "0 results";
}

}

$conn->close();
?>
