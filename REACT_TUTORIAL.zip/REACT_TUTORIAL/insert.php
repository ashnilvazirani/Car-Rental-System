<?php

header("Access-Control-Allow-Origin:http://localhost:3000");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, X-Requested-With");

require_once('headers_define.php');
require_once("connect.php");

$post_data = file_get_contents("php://input");
if(isset($post_data) && !empty($post_data)){
    $conn = connectDB();
    $req = json_decode($post_data);
    if(strcmp("enquiry",$req->requestor)==0){
            echo "inside enquiry";
            if(count(json_decode($post_data, true))==5){
            echo "inside count";
            $name = $req->name;
            $mobile = $req->mobile;
            $email = $req->email;
            $comments = $req->comments;
            $sql = "INSERT INTO enquiry(`name`, `mobile`, `email`, `comments`, `deleted`) 
            VALUES ('$name', '$mobile', '$email', '$comments', 0)";
            if ($conn->query($sql) === TRUE) {
                echo "New record created successfully";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        }//count    
    }//requestor
    $conn->close();
}//isset

?>