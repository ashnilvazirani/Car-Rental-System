import {Container, Row, Card, Col, Button, Form} from 'react-bootstrap';
import React, { Component } from 'react'
import axios from 'axios'
import MultiRef from 'react-multi-ref' 
export class ViewCardDetails extends Component {
    constructor(props) {
        super(props)
        this.state = {
            car: [],
            pickup_date:'',
            pickup:'',
             data: '',
             exp: '',
             image: '',
             title: '',
             text: '',
             muted: '',
             value: '0'
        }
        this.buttonRef = new MultiRef()
        this.appendData = this.appendData.bind(this);
        this.getDataDisplayed = this.getDataDisplayed.bind(this);
        this.checkBookingPermit = this.checkBookingPermit.bind(this);
        this.routeToBook = this.routeToBook.bind(this);
    }
    
    appendData(id){
        // alert(id)
        const getCarbyId = async () => {
            const results = await axios.get('http://localhost/REACT_TUTORIAL/select_car.php?cid='+id+'');
            this.setState({ car: results.data });
            this.state.car.map(car=>
                this.setState({
                    image: (require('../../image-content/car_image/'+car.car_image)),
                    title: car.car_name,
                    text: car.car_description,
                    muted: car.car_brand
                })    
            )
        }
        getCarbyId()
        // this.setState({
        //     exp: '<h1>HELLO</h1>',
        //     image: (require('../images/car'+id+'.jpeg')),
        //     title: 'Card title',
        //     text: 'This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.',
        //     muted: 'Last updated 3 mins ago'
        // });
    }
    formatDate(date) {
        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();
    
        if (month.length < 2) 
            month = '0' + month;
        if (day.length < 2) 
            day = '0' + day;
    
        return [year, month, day].join('-');
    }
    routeToBook(id){
            window.location.href="/bookingform?"+id;
    }
    checkBookingPermit(id){
        var today = new Date();
        var date = this.formatDate(today);
        const getCarBookingDate = async()=>{
            const results = await axios.get('http://localhost/REACT_TUTORIAL/select_car.php?cid='+id+'&date=1');
            this.setState({ pickup_date: results.data });
            console.log(this.state.pickup_date)
            if(this.state.pickup_date){
                this.state.pickup_date.map(pd=>
                    this.setState({
                        pickup: pd.pickup_date
                    })    
                );
                if(!date.localeCompare(this.state.pickup)){
                    alert("CANNOT BOOK THIS CAR RIGHT NOW!!!")
                    this.buttonRef.map.get(id).disabled=true;   
                    
                }else{
                    alert("GO AHEAD AND GRAB THE BEAUTY!!!")
                    // window.location.href="/bookingform?"+id;
                    this.routeToBook(id);
                }
            }else{
                alert("GO AHEAD AND GRAB THE BEAUTY!!!")
                this.routeToBook(id);
            }
        }
        getCarBookingDate();
    
    }
    getDataDisplayed(p){
        const displayData=[];
                displayData.push(<Card style={{ width: '18rem' }}>
                    <Card.Body>
                        <Card.Title>{p.car_name}</Card.Title>
                        <Card.Subtitle className="mb-2 text-muted">{p.car_brand}</Card.Subtitle>
                        <Card.Text>
                            {p.car_description}
                        </Card.Text>
                        <Card.Link><Button onClick={()=>this.appendData(p.car_id)}>View</Button></Card.Link>
                    <Card.Link><Button onClick={()=>this.checkBookingPermit(p.car_id)} ref={this.buttonRef.ref(p.car_id)}>Book</Button></Card.Link>
                </Card.Body>
                </Card>);
        return(displayData);
    }
    render() {
        const { posts, loading } = this.props;
        if (loading) {
            return <h2>Loading...</h2>
        }
        
        return (
            <Container>
            <Row>
                <Col>
                {    
                posts.map(post=>
                    this.getDataDisplayed(post)
                )}
                </Col>
                <Col>
                <div className="card">
                <img className="card-img-top" src={this.state.image} alt="" />
                <div className="card-body">
                <h5 className="card-title">{this.state.title}</h5>
                <p className="card-text">{this.state.text}</p>
                </div>
                <div className="card-footer">
                <small className="text-muted">{this.state.muted}</small>
                </div>
                </div>
                </Col>
            </Row>
            </Container>

        )
    }
}

export default ViewCardDetails

