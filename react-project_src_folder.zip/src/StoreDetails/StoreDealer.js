import React, {Component} from 'react'
import { Form } from 'react-bootstrap';
import { Button } from 'react-bootstrap';
import '../Custom.css';
import axios from 'axios';
export class StoreDealer extends Component {
    constructor(props) {
        super(props)
        this.state = {
            car_dealer_id:'',
            dealer_name:'',
            dealer_company_name:'',
            dealer_company_address:'',   
            dealer_number:'',
            dealer_email: '',
            status: 0,
            file: null,
            requestor:''
        }
        this.onChangeInInput = this.onChangeInInput.bind(this);
        this.sendData = this.sendData.bind(this);
        this.fileHandler = this.fileHandler.bind(this);
    }
    onChangeInInput=(event)=>{
        this.setState({
            [event.target.name]: event.target.value
        });
    }
    fileHandler = (event) =>{
        this.setState({
            file: event.target.files
        })   
    }
    sendData= (event) =>{
        event.preventDefault();
        let reader = new FileReader();
        reader.readAsDataURL(this.state.file[0]);
        reader.onload = (event) =>{
            const url = 'http://localhost/REACT_TUTORIAL/image_tester.php'
            const formData = {fileName: event.target.result, nameOfImage: this.state.file[0].name}
            axios.post(url, formData).then(response=>console.warn('result',response))   
         }//reader event closing

         const data1 ={
            dealer_name: this.state.dealer_name,
            dealer_company_name:this.state.dealer_company_name,
            dealer_company_address:this.state.dealer_company_address,   
            dealer_number:this.state.dealer_number,
            dealer_email: this.state.dealer_email,
            dealer_identity: this.state.file[0].name,
            status:'0',
            requestor:'car_dealer'
        } 
            axios.post('http://localhost/REACT_TUTORIAL/store_dealer.php',data1).then(res=>console.log(res.data));
            window.location.reload();
    }//sendData closing
        
    render() {
        return (
            <div className="container col-md-8">
                <Form onSubmit={(event)=>this.sendData(event)} name="store_dealer">
                <Form.Group controlId="">
                <Form.Label>Name</Form.Label>
                <Form.Control type="text" placeholder="Enter Your full Name" value={this.state.dealer_name} onChange={this.onChangeInInput} name="dealer_name"/>
                </Form.Group>

                <Form.Group controlId="">
                <Form.Label>Mobile Number</Form.Label>
                <Form.Control type="number" placeholder="Contact Number" value={this.state.dealer_number} onChange={this.onChangeInInput} name="dealer_number"/>
                </Form.Group>
                
                <Form.Group controlId="">
                <Form.Label>Email address</Form.Label>
                <Form.Control type="email" placeholder="Enter email" value={this.state.dealer_email} onChange={this.onChangeInInput} name="dealer_email"/>
                <Form.Text className="text-muted">
                    We'll never share your email with anyone else.
                </Form.Text>
                </Form.Group>
    
                <Form.Group controlId="">
                <Form.Label>Company Name</Form.Label>
                <Form.Control type="text" placeholder="Company name" value={this.state.dealer_company_name} onChange={this.onChangeInInput} name="dealer_company_name"/>
                </Form.Group>

                <Form.Group controlId="">
                <Form.Label>Company Address</Form.Label>
                <Form.Control type="text" placeholder="Company Address" value={this.state.dealer_company_address} onChange={this.onChangeInInput} name="dealer_company_address"/>
                </Form.Group> 
    
                <Form.Group controlId="">
                <Form.Label>Identity</Form.Label>
                <Form.Control type="file" accept=".png, .jpg, .jpeg" placeholder="dealer Identity" value={this.state.dealer_identity} onChange={(event)=>this.fileHandler(event)} name="dealer_identity"/>
                </Form.Group>
                
                <Button variant="primary" type="submit">
                    Submit
                </Button>
              </Form>            
            </div>
        )
    }
}

export default StoreDealer

