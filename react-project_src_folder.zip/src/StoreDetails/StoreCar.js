import React, { Component } from 'react';
import {Form, Button, Dropdown, DropdownButton} from 'react-bootstrap';
import axios from 'axios';
export class StoreCar extends Component {
    constructor(props) {
        super(props)
    
        this.state = {
            dealers:[],
            car_dealer_id:'',
            dealer_name:'SELECT',
            car_id:'',
            car_brand:'',
            car_name:'',
            car_number:'',
            car_model:'',
            car_description:'',
            file:null,
            car_image:'',
            car_charges:'',
            car_dealer_id:'',
            status:''
        }
        this.getSelectedDealer = this.getSelectedDealer.bind(this);
    }
    componentDidMount(){
        axios.get('http://localhost/REACT_TUTORIAL/select_dealers.php?car=1').then(
            response => {this.setState({
                dealers: response.data
            })
        })
    }
    getSelectedDealer(event){
        this.setState({
            car_dealer_id: event,
            dealer_name: "CHOOSED!!"
        })
    }
    displayDealers(){
        return(this.state.dealers.map(function(dealer,i){
        return(<Dropdown.Item eventKey={dealer.car_dealer_id} value={dealer.dealer_name}>{dealer.dealer_name}</Dropdown.Item>)
        }))
    }
    onChangeInInput=(event)=>{
        this.setState({
            [event.target.name]: event.target.value
        });
    }
    fileHandler = (event) =>{
        this.setState({
            file: event.target.files
        })   
    }
    
    sendData= (event) =>{
        event.preventDefault();
        let reader = new FileReader();
        reader.readAsDataURL(this.state.file[0]);
        reader.onload = (event) =>{
            const url = 'http://localhost/REACT_TUTORIAL/image_tester.php?car=1';
            const formData = {fileName: event.target.result, nameOfImage: this.state.file[0].name};
            console.log('IMAGE'+formData.fileName)
            axios.post(url, formData).then(response=>console.warn('result',response))   
         }//reader event closing

         const data1 ={
            car_brand: this.state.car_brand,
            car_name:this.state.car_name,
            car_number:this.state.car_number,
            car_model:this.state.car_model,
            car_description: this.state.car_description,
            car_charges: this.state.car_charges,
            car_dealer_id: this.state.car_dealer_id,
            car_image: this.state.file[0].name,
            status:'0',
            requestor:'cars'
        } 
            axios.post('http://localhost/REACT_TUTORIAL/store_car.php',data1).then(res=>console.log(res.data));
            // window.location.reload();
    }//sendData closing
    render() {
        return (
            <div>
                <div className="container col-md-8">
                <Form onSubmit={(event)=>this.sendData(event)} name="store_dealer">
                <Form.Group controlId="">
                <Form.Label>Car Brand</Form.Label>
                <Form.Control type="text" placeholder="Car Brand name" value={this.state.car_brand} onChange={this.onChangeInInput} name="car_brand"/>
                </Form.Group>
                
                <Form.Group controlId="">
                <Form.Label>Car Name</Form.Label>
                <Form.Control type="text" placeholder="Car Name" value={this.state.car_name} onChange={this.onChangeInInput} name="car_name"/>
                </Form.Group>

                <Form.Group controlId="">
                <Form.Label>Car Number</Form.Label>
                <Form.Control type="text" placeholder="Car Number" value={this.state.car_number} onChange={this.onChangeInInput} name="car_number"/>
                </Form.Group>
                
                <Form.Group controlId="">
                <Form.Label>Car Model</Form.Label>
                <Form.Control type="text" placeholder="Enter model name/number" value={this.state.car_model} onChange={this.onChangeInInput} name="car_model"/>
                </Form.Group>
    
                <Form.Group controlId="">
                <Form.Label>Car Description</Form.Label>
                <Form.Control type="text" placeholder="Something good about the car!" value={this.state.car_description} onChange={this.onChangeInInput} name="car_description"/>
                </Form.Group>

                <Form.Group controlId="">
                <Form.Label>Charges</Form.Label>
                <Form.Control type="number" placeholder="rate? per km" value={this.state.car_charges} onChange={this.onChangeInInput} name="car_charges"/>
                </Form.Group> 
    
                <Form.Group controlId="">
                <Form.Label>Identity</Form.Label>
                <Form.Control type="file" accept=".png, .jpg, .jpeg" placeholder="Car Images" value={this.state.car_images} onChange={(event)=>this.fileHandler(event)} name="car_images"/>
                </Form.Group>

                <Form.Group controlId="">
                <Form.Label>Select Dealer</Form.Label>
                <DropdownButton id="dropdown-basic-button" title={this.state.dealer_name} onSelect={(event)=>this.getSelectedDealer(event)}>
                    {this.displayDealers()}
                </DropdownButton>
                </Form.Group>

                <Button variant="primary" type="submit">
                    Submit
                </Button>
              </Form>            
              </div>
            </div>
        )
    }
}

export default StoreCar
