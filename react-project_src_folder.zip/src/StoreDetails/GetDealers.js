import React, { Component } from 'react'
import {DropdownButton, Dropdown} from 'react-bootstrap'
import axios from 'axios'
export class GetDealers extends Component {
    constructor(props) {
        super(props)
    
        this.state = {
             dealers:[]
        }
    }
    

    
    render() {
        return (
              <div></div>  
        )
    }
}

export default GetDealers
