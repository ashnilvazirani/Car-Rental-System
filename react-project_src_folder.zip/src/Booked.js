import React from 'react'
import {Card} from './Card'
function Booked() {
    return (
        <div>
            <Card />
        </div>
    )
}

export default Booked
