import React, { Component } from 'react';
import axios from 'axios';
import Posts from './ViewCarDetails/Posts';
import Pagination from './ViewCarDetails/Pagination';
import { Container } from 'react-bootstrap';

export class ViewCarDetails extends Component {
  constructor(props) {
    super(props)
  
    this.state = {
      posts: [],
      loading: false,
      currentPage: 1,
      postsPerPage: 3,
      cars: []       
    }
    this.displayDealers = this.displayDealers.bind(this); 
  }
displayDealers(){
    // var carData = [];
    console.log(this.state.cars) 
    // return(this.state.cars.map(function(car,i){
        // return(<DealerList data={dealer} index={i} key={dealer.car_dealer_id}/>)
    // }))
}

  // componentDidMount() {
  //   const getPosts = async () => {
  //     axios.get('http://localhost/REACT_TUTORIAL/select_car.php').then(
  //       response => {this.setState({
  //           cars: response.data
  //       })
  //   })
  //     this.setState({ loading: true });
  //     var content=[];
  //     var results =  new Array(1).fill(new Array(1).fill(content));
  //     this.setState({ posts: results });
  //     this.setState({ loading: false });
  //   };//async closing

  //   getPosts();
  //   this.displayDealers();
  // }

  componentDidMount() {
    const getPosts = async () => {
      this.setState({ loading: true });
      const results = await axios.get('http://localhost/REACT_TUTORIAL/select_car.php');
    console.log(results.data[2].car_name);
      this.setState({ posts: results.data });
      this.setState({ loading: false });
    };

    getPosts();
  }

  render() {
    const { currentPage, postsPerPage, posts, loading } = this.state;

    const indexOfLastPost = currentPage * postsPerPage;
    const indexOfFirstPost = indexOfLastPost - postsPerPage;
    const currentPosts = posts.slice(indexOfFirstPost, indexOfLastPost);

    const paginate = pageNum => this.setState({ currentPage: pageNum });

    const nextPage = () => this.setState({ currentPage: currentPage + 1 });

    const prevPage = () => this.setState({ currentPage: currentPage - 1 });
    

    return (
      <Container>
        <Posts posts={currentPosts} loading={loading} />
        <Pagination postsPerPage={postsPerPage} totalPosts={posts.length} paginate={paginate} nextPage={nextPage} prevPage={prevPage} />
      </Container>
    )
  }
}

export default ViewCarDetails