import React from 'react';
import './Custom.css';
import Seperator from './Seperator';
import {Card} from './Card';
export const Home = () => (
  <div>
  <div>
    <h2>Hello Public</h2>
    <p>Stare at ceiling lay on arms while you're using the keyboard so this human feeds me, i should be a god wack the mini furry mouse but all of a sudden cat goes crazy get suspicious of own shadow then go play with toilette paper. All of a sudden cat goes crazy wake up human for food at 4am stick butt in face, and peer out window, chatter at birds, lure them to mouth, knock over christmas tree. Scamper run up and down stairs lie on your belly and purr when you are asleep but attack the child. Warm up laptop with butt lick butt fart rainbows until owner yells pee in litter box hiss at cats hiding behind the couch until lured out by a feathery toy leave hair everywhere have secret plans so meow meow, i tell my human, so bite the neighbor's bratty kid find empty spot in cupboard and sleep all day. Need to chase tail wake up human for food at 4am. Chase ball of string sniff catnip and act crazy throw down all the stuff in the kitchen hide from vacuum cleaner.</p>
    <p>Meow meow, i tell my human purr for no reason but chase after silly colored fish toys around the house thinking longingly about tuna brine hack, but where is my slave? I'm getting hungry. Meow for food, then when human fills food dish, take a few bites of food and continue meowing i like frogs and 0 gravity but immediately regret falling into bathtub. Brown cats with pink ears i shredded your linens for you wake up wander around the house making large amounts of noise jump on top of your human's bed and fall asleep again kitten is playing with dead mouse or destroy house in 5 seconds. Make plans to dominate world and then take a nap missing until dinner time catch mouse and gave it as a present fat baby cat best buddy little guy. Meow leave hair everywhere. Refuse to come home when humans are going to bed; stay out all night then yowl like i am dying at 4am sit in box, purr. Give me some of your food give me some of your food give me some of your food meh, i don't want it if it fits, i sits. Fall over dead (not really but gets sypathy) you have cat to be kitten me right meow. Being gorgeous with belly side up eat too much then proceed to regurgitate all over living room carpet while humans eat dinner, and slap the dog because cats rule chew the plant meow meow mama sniff all the things yet stand in front of the computer screen. I just saw other cats inside the house and nobody ask me before using my litter box all of a sudden cat goes crazy. Poop on grasses give me some of your food give me some of your food give me some of your food meh, i don't want it cat slap dog in face and love me! chew the plant chase dog then run away ptracy.</p>
  </div>
        <Seperator />
        <h6 class="text-uppercase">Sample Cars</h6>
        <Card />
        <div class="btn-toolbar">
        <div class="btn-group">
          <button>1</button>
          <button>2</button>
          <button>3</button>
          <button>4</button>
          <button>5</button>
        </div>
        </div>
  </div>
)
