import React, {Component} from 'react'
import { Form } from 'react-bootstrap';
import { Button } from 'react-bootstrap';
import './Custom.css';
import axios from 'axios';
export class ContactForm extends Component {
    constructor(props) {
        super(props)
    
        this.state = {
            id:'',
            name:'',
            email:'',
            mobile:'',   
            comments:''           
        }
        this.onChangeInInput = this.onChangeInInput.bind(this);
        this.sendData = this.sendData.bind(this);
    }
    onChangeInInput=(event)=>{
        this.setState({
            [event.target.name]: event.target.value
        });
        
    }
    sendData= (event) =>{
        event.preventDefault();
        const data1 ={
            requestor: 'enquiry',
            name: this.state.name,
            email: this.state.email,
            mobile: this.state.mobile,
            comments: this.state.comments
        }
        // axios.post('/CRUD/insert.php',data).then(res => console.log(res.data));
        // axios.post('', data)
        //   .then(function (response) {
        //     console.log(response);
        //   })
        // const proxyurl = "https://cors-anywhere.herokuapp.com/";
        // const url = "http://localhost/REACT_TUTORIAL/insert.php"; // site that doesn’t send Access-Control-*
        // fetch(proxyurl+url)
        // .then(data1 => data1.text())
        // .then(contents => console.log(contents))
        // .catch(() => console.log("Can’t access " + url + " response. Blocked by browser?"))
        
        axios.post('http://localhost/REACT_TUTORIAL/insert.php',data1).then(res=>console.log(res.data));
        console.log(data1);
        window.location.reload();
    }

    render() {
        return (
            <div>
                <Form onSubmit={this.sendData} name="enquiry_form">
                <Form.Group controlId="">
                <Form.Label>Name</Form.Label>
                <Form.Control type="text" placeholder="Enter Your full Name" value={this.state.name} onChange={this.onChangeInInput} name="name"/>
                </Form.Group>
                <Form.Group controlId="">
                <Form.Label>Mobile Number</Form.Label>
                <Form.Control type="number" placeholder="Contact Number" value={this.state.mobile} onChange={this.onChangeInInput} name="mobile"/>
                </Form.Group>
                
                <Form.Group controlId="">
                <Form.Label>Email address</Form.Label>
                <Form.Control type="email" placeholder="Enter email" value={this.state.email} onChange={this.onChangeInInput} name="email"/>
                <Form.Text className="text-muted">
                    We'll never share your email with anyone else.
                </Form.Text>
                </Form.Group>
    
                <Form.Group controlId="">
                <Form.Label>Additonal Comments</Form.Label>
                <Form.Control type="textarea" placeholder="Additonal Comments" value={this.state.comments} onChange={this.onChangeInInput} name="comments"/>
                </Form.Group>
    
                <Form.Group controlId="">
                <Form.Check type="checkbox" label="Tick to confirm that you`re new here" />
                </Form.Group>
                <Button variant="primary" type="submit">
                    Submit
                </Button>
              </Form>            
            </div>
        )
    }
}

export default ContactForm

