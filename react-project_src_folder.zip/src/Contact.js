import React from 'react';
import ContactForm from './ContactForm'
export const Contact = () => (

  // <!-- Start contact-page Area -->
  <section className="contact-page-area section-gap">
    <div className="container">
      <div className="row">
        <div className="col-lg-4 d-flex flex-column address-wrap">
          <div className="single-contact-address d-flex flex-row">
            <div className="icon">
              <span className="lnr lnr-home"></span>
            </div>
            <div className="contact-details">
              <h5>Dhaka, Bangladesh</h5>
              <p>56/8, West Panthapath</p>
            </div>
          </div>
          <div className="single-contact-address d-flex flex-row">
            <div className="icon">
              <span className="lnr lnr-phone-handset"></span>
            </div>
            <div className="contact-details">
              <h5>00 (880) 9865 562</h5>
              <p>Mon to Fri 9am to 6 pm</p>
            </div>
          </div>
          <div className="single-contact-address d-flex flex-row">
            <div className="icon">
              <span className="lnr lnr-envelope"></span>
            </div>
            <div className="contact-details">
              <h5>support@codethemes.com</h5>
              <p>Send us your query anytime!</p>
            </div>
          </div>														
        </div>
        <div className="col-lg-6">
        	<ContactForm />
      </div>
      </div>
    </div>	
  </section>
  // <!-- End contact-page Area -->
)
