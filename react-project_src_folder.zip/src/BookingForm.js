import React, { Component } from 'react'
import {Form, Dropdown, DropdownButton, Button} from 'react-bootstrap'
import axios from 'axios'

export class BookingForm extends Component {
    constructor(props) {
        super(props)
        console.log(this.props.location.search.slice(1))
        this.state = {
            car_id: this.props.location.search.slice(1),
            customer_name:'',
            customer_email:'',
            customer_number:'',
            pickup_address:'',
            destination_address:'',
            trip_type:'',
            pickup_date:'',
            drop_date:'',
            comments:'',
            status:''
        }
        this.sendData = this.sendData.bind(this)
        this.onChangeInInput = this.onChangeInInput.bind(this)
        this.getSelectedValue = this.getSelectedValue.bind(this)
    }
    onChangeInInput=(event)=>{
        this.setState({
            [event.target.name]: event.target.value
        });
    }
    getSelectedValue = (event)=>{
        this.setState({
            trip_type: event
        })
    }
    sendData= (event) =>{
        event.preventDefault();
         const data1 ={
            car_id:this.state.car_id,
            customer_name:this.state.customer_name,
            customer_email:this.state.customer_email,
            customer_number:this.state.customer_number,
            pickup_address:this.state.pickup_address,
            destination_address:this.state.destination_address,
            pickup_date:this.state.pickup_date,
            drop_date:this.state.drop_date,
            trip_type:this.state.trip_type,
            comments:this.state.comments,
            status:'0',
            requestor:'car_request'
        } 
        console.log(data1)
            axios.post('http://localhost/REACT_TUTORIAL/store_request.php',data1).then(res=>console.log(res.data));
            window.location.reload();
    }//sendData closing

    render() {
        return (
            <Form onSubmit={(event)=>this.sendData(event)}>
                    <Form.Group controlId="formBasicEmail">
                    <Form.Label>Email address</Form.Label>
                    <Form.Control type="email" placeholder="Enter email" value={this.state.customer_email} onChange={this.onChangeInInput} name="customer_email" />
                    </Form.Group>
                    <Form.Group controlId="formBasicPassword">
                    <Form.Label>Full Name</Form.Label>
                    <Form.Control type="text" placeholder="Full Name" value={this.state.customer_name} onChange={this.onChangeInInput} name="customer_name" />
                    </Form.Group>
                    <Form.Group controlId="formBasicPassword">
                    <Form.Label>Mobile Number</Form.Label>
                    <Form.Control type="text" placeholder="Contact details" value={this.state.customer_number} onChange={this.onChangeInInput} name="customer_number" />
                    </Form.Group>
                    <Form.Group controlId="formBasicPassword">
                    <Form.Label>Address</Form.Label>
                    <Form.Control type="text" placeholder="Pick Up place..." value={this.state.puckup_address} onChange={this.onChangeInInput} name="puckup_address" />
                    </Form.Group>
                    <Form.Group controlId="formBasicPassword">
                    <Form.Label>Destionation</Form.Label>
                    <Form.Control type="text" placeholder="To place place..." value={this.state.destination_address} onChange={this.onChangeInInput} name="destination_address" />
                    </Form.Group>
                    <Form.Group controlId="formBasicPassword">
                    <Form.Label>Select your trip</Form.Label>
                    <DropdownButton id="dropdown-basic-button" title="--TRIP TYPE--" value={this.state.trip_type} name="trip_type" onSelect={(event)=>this.getSelectedValue(event)}>
                    <Dropdown.Item eventKey='1'>Single trip</Dropdown.Item>
                    <Dropdown.Item eventKey='2'>Round trip</Dropdown.Item>
                    </DropdownButton>
                    </Form.Group>
                    <Form.Group controlId="formBasicPassword">
                    <Form.Label>From Date</Form.Label>
                    <Form.Control type="date" placeholder="From Date" value={this.state.pickup_date} onChange={this.onChangeInInput} name="pickup_date"/>
                    </Form.Group>
                    <Form.Group controlId="formBasicPassword">
                    <Form.Label>To Date</Form.Label>
                    <Form.Control type="date" placeholder="TO Date" value={this.state.drop_date} onChange={this.onChangeInInput} name="drop_date" />
                    </Form.Group>
                    <Form.Group controlId="formBasicPassword">
                    <Form.Label>Additonal Comments?</Form.Label>
                    <Form.Control type="text" placeholder="Aur abatao?" value={this.state.comments} onChange={this.onChangeInInput} name="comments" />
                    </Form.Group>
                    <Button variant="primary" type="submit">
                        Submit
                    </Button>
                </Form>	

        )
    }
}

export default BookingForm
