import React, {Component} from 'react';
import './Custom.css';
import Post from './Posts'
import axios from 'axios'

export class Card extends Component {
  constructor(props) {
    super(props)
  
    this.state = {
       cars:[]
    }
    this.createPosts = this.createPosts.bind(this)
  }
  
  componentDidMount(){
    axios.get('http://localhost/REACT_TUTORIAL/select_booked_cars.php').then(
      response => {this.setState({
        cars: response.data
      })
  })
}
createPosts(){
  let posts=[];
  console.log(this.state.cars);
  this.state.cars.map(function(car, i){
    posts.push(
      <Post 
      image={require('./images/car2.jpeg')}
      title={car.car_name + car.car_model}
      text={car.car_description}
      mutedText={car.car_brand}
      key={i}
    />
  )
})
    // posts.push(</div>);
    console.log(posts.length);
  return(posts);
}

  render() {
    return (
      <div>
        <div className="card-deck AlignCenter row container">
        {this.createPosts()}
        </div>
      </div>
      
    )
  }
}

export default Card
