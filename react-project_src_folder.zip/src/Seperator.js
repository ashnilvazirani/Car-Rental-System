
import React from 'react'

function Seperator() {
    return (
        <div className="mb-4">
    {/* <h6 class="text-uppercase"></h6> */}
    {/* Solid divider  */}
    <hr className="solid" /> 
    </div>
    )
}

export default Seperator
