import React, { Component } from 'react'
import axios from 'axios';
import {Table} from 'react-bootstrap';
import DealerList from './DealerList';

export class ViewDealers extends Component {
    constructor(props) {
        super(props)
    
        this.state = {
             dealers: []
        }
    }
    componentDidMount(){
        axios.get('http://localhost/REACT_TUTORIAL/select_dealers.php').then(
            response => {this.setState({
                dealers: response.data
            })
        })
    }
    displayDealers(){
        return(this.state.dealers.map(function(dealer,i){
            return(<DealerList data={dealer} index={i} key={dealer.car_dealer_id}/>)
        }))
    }
    render() {
        return (
            <div>
                <Table striped bordered hover variant="dark">
                <thead>
                    <tr>
                    <th>#</th>
                    <th>Full Name</th>
                    <th>Company Name</th>
                    <th>Company Address</th>
                    <th>Contact</th>
                    <th>Edit</th>
                    <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    {this.displayDealers()}
                </tbody>
                </Table>
            </div>
        )
    }
}

export default ViewDealers

