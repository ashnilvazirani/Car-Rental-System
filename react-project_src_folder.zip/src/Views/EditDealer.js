import React, { Component } from 'react'
import EditModal from'./EditModalForm'
import {Modal, Button} from 'react-bootstrap'
import axios from 'axios';

export class EditDealer extends Component {

    constructor(props) {
        super(props)
    
        this.state = {
            show: false,
            setShow: false,
            dealers: []
        }
    }
    
    componentDidMount(){
        axios.get('http://localhost/REACT_TUTORIAL/select_dealers.php?did='+this.props.did).then(
            response => {this.setState({
                dealers: response.data
            })
        })
    }

    editDealerModal(){
        console.log(this.state.dealers)
        return(this.state.dealers.map(function(dealer){
            return(<EditModal dealerdata={dealer} key={dealer.car_dealer_id}/>)
        }))
    }
    
    handleClose = () => this.setState({setShow: false, show: false});
    handleShow = () => {
        this.setState({
            setShow:true,
            show:true,
        });
        
    }
    render() {
        return (
            <div>
                <Button variant="primary" onClick={this.handleShow}>
                    EDIT
                </Button>
    
                <Modal show={this.state.show} onHide={this.handleClose}>
                    <Modal.Header closeButton>
                    <Modal.Title>Update Records</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        {this.editDealerModal()}
                    </Modal.Body>
                    <Modal.Footer>
                    <Button variant="secondary" onClick={this.handleClose}>
                        Close
                    </Button>
                    </Modal.Footer>
                </Modal>
            </div>
        )
    }
}

export default EditDealer

