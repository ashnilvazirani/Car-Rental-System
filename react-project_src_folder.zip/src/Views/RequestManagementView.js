import React, { Component } from 'react'
import axios from 'axios';
import {Table} from 'react-bootstrap';
import RequestList from './RequestList';
export class RequestManagementView extends Component {
    constructor(props) {
        super(props)
        var carName=[];
        this.state = {
            requests: [],
             dealers:[]
        }
        // this.getData = this.getData.bind(this);
        this.displayDealers = this.displayDealers.bind(this);
    }
    componentDidMount(){
        axios.get('http://localhost/REACT_TUTORIAL/select_request.php').then(
            response => {this.setState({
                requests: response.data
            })
        })
    }
    displayDealers=()=>{
        // console.log(tp)
        // carName.map((dn)=>{console.log(dn.dearler_name[1])})
        return(this.state.requests.map(function(request,i){
            return(<RequestList data={request} index={i} key={request.request_id} />)
        }))
    }
    render() {
        // {console.log(this.state.cars)}
        return (
            <div>
                <Table striped bordered hover variant="dark">
                <thead>
                    <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Contact</th>
                    <th>Location</th>
                    <th>Dates</th>
                    <th>Car Name</th>
                    <th>Approve</th>
                    <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    {this.displayDealers()}
                </tbody>
                </Table>
            </div>
        )
    }
}

export default RequestManagementView

