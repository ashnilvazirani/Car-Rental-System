import React, { Component } from 'react'
import { Button } from 'react-bootstrap';
import axios from 'axios';
import EditCar from './EditCar';
export class RequestList extends Component {
    constructor(props) {
        super(props)
        this.state={
            carName:[]
        }        
    }
    
    componentDidMount(){
        axios.get('http://localhost/REACT_TUTORIAL/select_car.php?cid='+this.props.data.car_id+'&carName=1').then(
            response => {this.setState({
                carName: response.data
            })
        })
       
    }
    deleteCarRecord(event){
        alert(event.target.value)
        if(window.confirm("Are you sure you wish to delete the record?")) {
            const data1={
                requestor: 'car_request',
                request_id: event.target.value
            } 
            axios.post('http://localhost/REACT_TUTORIAL/delete.php',data1).then(res=>console.log(res.data));
            console.log(data1);
            window.location.reload();
        }
    }

    approveRequest(event){
        alert(this.props.data.car_id)
        if(window.confirm("Are you sure you wish to approve the record?")) {
            const data1={
                requestor: 'car_request',
                request_id: event.target.value,
                car_id: this.props.data.car_id
            } 
            axios.post('http://localhost/REACT_TUTORIAL/approve_request.php',data1).then(res=>console.log(res.data));
            console.log(data1);
            // window.location.reload();
        }
    }
    
    editRecord(edit_id){
        // return <EditCar car_id={edit_id} />
    }
    displayCars=()=>{
        return(this.state.carName.map(function(cn){
            return(cn.car_name)
        }))
    }
    render() {
        return (
                <tr>
                <td>
                    {this.props.index+1}
                </td>
                <td>
                    {this.props.data.customer_name}
                </td>
                <td>
                    {this.props.data.customer_number+' && '+this.props.data.customer_email}
                </td>
                <td>
                    {this.props.data.pickup_address+' TO '+this.props.data.destination_address}
                </td>
                <td>
                    {this.props.data.pickup_date+' TO '+this.props.data.drop_date}
                </td>
                <td>
                    {this.displayCars()}    
                </td>
                <td>
                    <Button onClick={(event)=>this.approveRequest(event)} value={this.props.data.request_id } className="btn btn-promary">APPROVE</Button>
                     {/* {this.editRecord(this.props.data.car_id)} */}
                </td>
                <td>
                    <Button onClick={(event)=>this.deleteCarRecord(event)} className="btn btn-danger" value={this.props.data.request_id }>DELETE</Button>
                </td>
                </tr>
        )
    }
}

export default RequestList
