import React, { Component } from 'react'
import { Button } from 'react-bootstrap';
import axios from 'axios';
import EditCar from './EditCar';
export class CarList extends Component {
    constructor(props) {
        super(props)
        this.state={
            dealerName:[]
        }        
    }
    
    componentDidMount(){
        axios.get('http://localhost/REACT_TUTORIAL/select_dealer_name.php?did='+this.props.data.car_dealer_id+'&namereq=1').then(
            response => {this.setState({
                dealerName: response.data
            })
        })
       
    }
    deleteCarRecord(event){
        if(window.confirm("Are you sure you wish to delete the record?")) {
            const data1={
                requestor: 'cars',
                car_id: event.target.value
            } 
            axios.post('http://localhost/REACT_TUTORIAL/delete.php',data1).then(res=>console.log(res.data));
            console.log(data1);
            window.location.reload();
        }
    }
    editRecord(edit_id){
        return <EditCar car_id={edit_id} />
    }
    displayDealers=()=>{
        return(this.state.dealerName.map(function(dn){
            return(dn.dealer_name)
        }))
    }
    render() {
        return (
                <tr>
                <td>
                    {this.props.index+1}
                </td>
                <td>
                    {this.props.data.car_name}
                </td>
                <td>
                    {this.props.data.car_brand}
                </td>
                <td>
                    {this.props.data.car_model}
                </td>
                <td>
                    {this.displayDealers()}    
                </td>
                <td>
                    {/* <Button onClick={this.editRecord()} className="btn btn-promary">EDIT</Button> */}
                     {this.editRecord(this.props.data.car_id)}
                </td>
                <td>
                    <Button onClick={(event)=>this.deleteCarRecord(event)} className="btn btn-danger" value={this.props.data.car_id }>DELETE</Button>
                </td>
                </tr>
        )
    }
}

export default CarList
