import React, { Component } from 'react'
import axios from 'axios'
import {Form, DropdownButton, Button, Dropdown} from 'react-bootstrap'
export class EditCarForm extends Component {
    constructor(props) {
        super(props)
    
        this.state = {
            dealers:[],
            car_dealer_id: this.props.cardata.car_dealer_id,
            dealer_name: 'SELECT',
            car_id:this.props.cardata.car_id,
            car_brand:this.props.cardata.car_brand,
            car_name:this.props.cardata.car_name,
            car_number:this.props.cardata.car_number,
            car_model:this.props.cardata.car_model,
            car_description:this.props.cardata.car_description,
            file:this.props.cardata.car_image,  
            fileStatus: false,
            car_image:this.props.cardata.car_image,
            car_charges:this.props.cardata.car_charges,
            status:this.props.cardata.status
        }
    }
    componentDidMount(){
        axios.get('http://localhost/REACT_TUTORIAL/select_dealers.php?car=1').then(
            response => {this.setState({
                dealers: response.data
            })
        })
    }
    displayDealers(){
        return(this.state.dealers.map(function(dealer,i){
        return(<Dropdown.Item eventKey={dealer.car_dealer_id} value={dealer.dealer_name}>{dealer.dealer_name}</Dropdown.Item>)
        }))
    }
    onChangeInInput=(event)=>{
        this.setState({
            [event.target.name]: event.target.value
        });
    }
    fileHandler = (event) =>{
        this.setState({
            fileStatus: true,
            file: event.target.files
        })   
    }
        
    sendData= (event) =>{
        event.preventDefault();
        if(this.state.fileStatus){
            let reader = new FileReader();
            reader.readAsDataURL(this.state.file[0]);
            reader.onload = (event) =>{
            const url = 'http://localhost/REACT_TUTORIAL/image_tester.php?car=1';
            const formData = {fileName: event.target.result, nameOfImage: this.state.file[0].name};
            axios.post(url, formData).then(response=>console.warn('result',response)) 
            this.setState({
                file: formData.nameOfImage
            })    
         }//reader event closing
        }

         const data1 ={
            car_brand: this.state.car_brand,
            car_name:this.state.car_name,
            car_number:this.state.car_number,   
            car_model:this.state.car_model,
            car_description: this.state.car_description,
            car_charges: this.state.car_charges,
            car_dealer_id: this.state.car_dealer_id,
            car_image: this.state.file,
            status:'0',
            requestor:'cars'
        } 
            axios.post('http://localhost/REACT_TUTORIAL/update_car.php?cid='+this.state.car_id,data1).then(res=>console.log(res.data));
            window.location.reload();
    }//sendData closing
    getSelectedDealer(event){
        this.setState({
            car_dealer_id: event,
            dealer_name: "CHOOSED!!"
        })
    }
    render() {
        return (
            <div>
                <Form onSubmit={(event)=>this.sendData(event)} name="store_dealer">
                <Form.Group controlId="">
                <Form.Label>Car Brand</Form.Label>
                <Form.Control type="text" placeholder={this.props.cardata.car_brand} value={this.state.car_brand} onChange={this.onChangeInInput} name="car_brand"/>
                </Form.Group>
                
                <Form.Group controlId="">
                <Form.Label>Car Name</Form.Label>
                <Form.Control type="text" placeholder={this.props.cardata.car_name} value={this.state.car_name} onChange={this.onChangeInInput} name="car_name"/>
                </Form.Group>

                <Form.Group controlId="">
                <Form.Label>Car Number</Form.Label>
                <Form.Control type="text" placeholder={this.props.cardata.car_number} value={this.state.car_number} onChange={this.onChangeInInput} name="car_number"/>
                </Form.Group>
                
                <Form.Group controlId="">
                <Form.Label>Car Model</Form.Label>
                <Form.Control type="text" placeholder={this.props.cardata.car_model} value={this.state.car_model} onChange={this.onChangeInInput} name="car_model"/>
                </Form.Group>
    
                <Form.Group controlId="">
                <Form.Label>Car Description</Form.Label>
                <Form.Control type="text" placeholder={this.props.cardata.car_description} value={this.state.car_description} onChange={this.onChangeInInput} name="car_description"/>
                </Form.Group>

                <Form.Group controlId="">
                <Form.Label>Charges</Form.Label>
                <Form.Control type="number" placeholder={this.props.cardata.car_charges} value={this.state.car_charges} onChange={this.onChangeInInput} name="car_charges"/>
                </Form.Group> 
    
                <Form.Group controlId="">
                <Form.Label>Identity</Form.Label>
                <Form.Control type="file" accept=".png, .jpg, .jpeg" placeholder={this.props.cardata.car_images} value={this.state.car_images} onChange={(event)=>this.fileHandler(event)} name="car_images"/>
                </Form.Group>

                <Form.Group controlId="">
                <Form.Label>Select Dealer</Form.Label>
                <DropdownButton id="dropdown-basic-button" title={this.props.cardata.car_dealer_id} onSelect={(event)=>this.getSelectedDealer(event)}>
                    {this.displayDealers()}
                </DropdownButton>
                </Form.Group>

                <Button variant="primary" type="submit">
                    Submit
                </Button>
              </Form>            
            </div>
        )
    }
}

export default EditCarForm
