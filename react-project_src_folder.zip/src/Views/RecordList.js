import React, { Component } from 'react'
import {Button} from 'react-bootstrap'
import axios from 'axios';
export class RecordList extends Component {
    constructor(props) {
        super(props)
        this.deleteEnquiryRecord = this.deleteEnquiryRecord.bind(this)
    }
    
    deleteEnquiryRecord(event){
        if (window.confirm("Are you sure you wish to delete the record?")) {
            const data1={
                requestor: 'enquiry',
                eid: event.target.value
            }
            axios.post('http://localhost/REACT_TUTORIAL/delete.php',data1).then(res=>console.log(res.data));
            console.log(data1);
            window.location.reload();
        }
    }
    render() {
        console.log(this.props.index);
        return (
                <tr>
                <td>
                    {this.props.index}
                </td>
                <td>
                    {this.props.data.name}
                </td>
                <td>
                    {this.props.data.email+" &&  "+this.props.data.mobile}
                </td>
                <td>
                    {this.props.data.comments}
                </td>
                <td>
                    <Button className="btn btn-promary">EDIT</Button>
                </td>
                <td>
                <Button onClick={(event)=>this.deleteEnquiryRecord(event)} className="btn btn-danger" value={this.props.data.eid}>DELETE</Button>
                </td>
                </tr>
        )
    }
}

export default RecordList
