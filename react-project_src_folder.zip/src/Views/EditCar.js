import React, { Component } from 'react'
import EditCarForm from'./EditCarForm'
import {Modal, Button} from 'react-bootstrap'
import axios from 'axios';

export class EditCar extends Component {
    constructor(props) {
        super(props)
    
        this.state = {
            show: false,
            setShow: false,
            cars: []
        }
        this.editCarModal = this.editCarModal.bind(this)
    }
    
    componentDidMount(){
        axios.get('http://localhost/REACT_TUTORIAL/select_car.php?cid='+this.props.car_id).then(
            response => {this.setState({
                cars: response.data
            })
        })
    }
    editCarModal(){
        console.log(this.state.cars)
        return(this.state.cars.map(function(car){
            return(<EditCarForm cardata={car} key={car.car_id}/>)
        }))
    }
    
    handleClose = () => this.setState({setShow: false, show: false});
    handleShow = () => {
        this.setState({
            setShow:true,
            show:true,
        });
        
    }
    
    render() {
        return (
            <div>
                <Button variant="primary" onClick={this.handleShow}>
                    EDIT
                </Button>
    
                <Modal show={this.state.show} onHide={this.handleClose}>
                    <Modal.Header closeButton>
                    <Modal.Title>Update Records</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        {this.editCarModal()}
                    </Modal.Body>
                    <Modal.Footer>
                    <Button variant="secondary" onClick={this.handleClose}>
                        Close
                    </Button>
                    </Modal.Footer>
                </Modal>
            </div>
        )
    }
}

export default EditCar
