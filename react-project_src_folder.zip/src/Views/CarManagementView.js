import React, { Component } from 'react'
import axios from 'axios';
import {Table} from 'react-bootstrap';
import CarList from './CarList';

export class CarManagementView extends Component {
    constructor(props) {
        super(props)    
        var dealerName=[];
        this.state = {
             cars: [],
             dealers:[]
        }
        // this.getData = this.getData.bind(this);
        this.displayDealers = this.displayDealers.bind(this);
    }
    componentDidMount(){
        axios.get('http://localhost/REACT_TUTORIAL/select_car.php').then(
            response => {this.setState({
                cars: response.data
            })
        })
       
    }
    displayDealers=()=>{
        // console.log(tp)
        // dealerName.map((dn)=>{console.log(dn.dearler_name[1])})
        return(this.state.cars.map(function(car,i){
            return(<CarList data={car} index={i} key={car.car_id} />)
        }))
    }
    render() {
        // {console.log(this.state.cars)}
        return (
            <div>
                <Table striped bordered hover variant="dark">
                <thead>
                    <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Brand Name</th>
                    <th>Model</th>
                    <th>Dealer Name</th>
                    <th>Edit</th>
                    <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    {this.displayDealers()}
                </tbody>
                </Table>
            </div>
        )
    }
}

export default CarManagementView

