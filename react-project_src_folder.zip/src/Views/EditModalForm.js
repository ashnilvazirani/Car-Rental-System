import React, { Component } from 'react'
import {Form, Button} from 'react-bootstrap'
import axios from 'axios'
export class EditModalForm extends Component {
    constructor(props) {
        super(props)
        this.state = {
            car_dealer_id: this.props.dealerdata.car_dealer_id,
            dealer_name: this.props.dealerdata.dealer_name,
            dealer_company_name:this.props.dealerdata.dealer_company_name,
            dealer_company_address:this.props.dealerdata.dealer_company_address,   
            dealer_number:this.props.dealerdata.dealer_number,
            dealer_email: this.props.dealerdata.dealer_email,
            status: 0,
            fileStatus: false,
            file: this.props.dealerdata.dealer_identity,
            requestor:'car_dealer'
        }
    }
    
    onChangeInInput=(event)=>{
        this.setState({
            [event.target.name]: event.target.value
        });
    }
    fileHandler = (event) =>{
        this.setState({
            fileStatus: true,
            file: event.target.files
        })   
    }

    sendData= (event) =>{
        event.preventDefault();
        if(this.state.fileStatus){
            let reader = new FileReader();
            reader.readAsDataURL(this.state.file[0]);
            reader.onload = (event) =>{
            const url = 'http://localhost/REACT_TUTORIAL/image_tester.php'
            const formData = {fileName: event.target.result, nameOfImage: this.state.file[0].name}
            axios.post(url, formData).then(response=>console.warn('result',response))
            this.setState({
                file: formData.nameOfImage
            })   
         }//reader event closing

        }
         const data1 ={
            dealer_name: this.state.dealer_name,
            dealer_company_name:this.state.dealer_company_name,
            dealer_company_address:this.state.dealer_company_address,   
            dealer_number:this.state.dealer_number,
            dealer_email: this.state.dealer_email,
            dealer_identity: this.state.file,
            status:'0',
            requestor:'car_dealer'
        } 
        console.log(data1);
            axios.post('http://localhost/REACT_TUTORIAL/update_dealer.php?did='+this.state.car_dealer_id, data1)
            .then(res=>console.log(res.data));
            window.location.reload();

    }//sendData closing
   
    render() {
        return (
            <div>
                <Form name="edit_dealer" onSubmit={(event)=>this.sendData(event)}>
                        <Form.Group controlId="">
                        <Form.Label>Name</Form.Label>
                        <Form.Control type="text" placeholder={this.props.dealerdata.dealer_name} value={this.state.dealer_name} onChange={this.onChangeInInput} name="dealer_name"/>
                        </Form.Group>

                        <Form.Group controlId="">
                        <Form.Label>Mobile Number</Form.Label>
                        <Form.Control type="number" placeholder={this.props.dealerdata.dealer_number} value={this.state.dealer_number} onChange={this.onChangeInInput} name="dealer_number"/>
                        </Form.Group>
                        
                        <Form.Group controlId="">
                        <Form.Label>Email address</Form.Label>
                        <Form.Control type="email" placeholder={this.props.dealerdata.dealer_email} value={this.state.dealer_email} onChange={this.onChangeInInput} name="dealer_email"/>
                        <Form.Text className="text-muted">
                            We'll never share your email with anyone else.
                        </Form.Text>
                        </Form.Group>
            
                        <Form.Group controlId="">
                        <Form.Label>Company Name</Form.Label>
                        <Form.Control type="text" placeholder={this.props.dealerdata.dealer_company_name} value={this.state.dealer_company_name} onChange={this.onChangeInInput} name="dealer_company_name"/>
                        </Form.Group>

                        <Form.Group controlId="">
                        <Form.Label>Company Address</Form.Label>
                        <Form.Control type="text" placeholder={this.props.dealerdata.dealer_company_address} value={this.state.dealer_company_address} onChange={this.onChangeInInput} name="dealer_company_address"/>
                        </Form.Group> 
            
                        <Form.Group controlId="">
                        <Form.Label>Identity</Form.Label>
                        <Form.Control type="file" accept=".png, .jpg, .jpeg" placeholder="dealer Identity" value={this.state.dealer_identity} onChange={(event)=>this.fileHandler(event)} name="dealer_identity"/>
                        </Form.Group>
                        <Button variant="primary" type="submit">
                            Submit
                        </Button>
                    </Form>
            </div>
        )
    }
}

export default EditModalForm
