import React, { Component } from 'react'
import axios from 'axios';
import {Table} from 'react-bootstrap';
import RecordList from './RecordList'
export class ViewEnquiries extends Component {
    constructor(props) {
        super(props)
    
        this.state = {
             enquiries: []
        }
    }
    componentDidMount(){
        axios.get('http://localhost/REACT_TUTORIAL/select_enquiries.php').then(
            response => {this.setState({
                enquiries: response.data
            })
        })
    }
    displayEnquiry(){
        return(this.state.enquiries.map(function(enquiry,i){
            return(<RecordList data={enquiry} index={i}/>)
        }))
    }
    render() {
        return (
            <div>
                <Table striped bordered hover variant="dark">
                <thead>
                    <tr>
                    <th>#</th>
                    <th>Full Name</th>
                    <th>Contact</th>
                    <th>Comments</th>
                    <th>Edit</th>
                    <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    {this.displayEnquiry()}
                </tbody>
                </Table>
            </div>
        )
    }
}

export default ViewEnquiries

