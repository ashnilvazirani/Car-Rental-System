import React, { Component } from 'react'
import { Button } from 'react-bootstrap';
import axios from 'axios';
import EditDealer from './EditDealer'
export class DealerList extends Component {
    constructor(props) {
        super(props)

        this.deleteDealerRecord = this.deleteDealerRecord.bind(this);
        this.editRecord = this.editRecord.bind(this);
    }
    
    deleteDealerRecord(event){
        if (window.confirm("Are you sure you wish to delete the record?")) {
            const data1={
                requestor: 'car_dealer',
                car_dealer_id: event.target.value
            }
            axios.post('http://localhost/REACT_TUTORIAL/delete.php',data1).then(res=>console.log(res.data));
            console.log(data1);
            window.location.reload();
        }
    }
    editRecord(edit_id){
        return <EditDealer did={edit_id} />
    }
    render() {
        return (
                <tr>
                <td>
                    {this.props.index}
                </td>
                <td>
                    {this.props.data.dealer_name}
                </td>
                <td>
                    {this.props.data.dealer_company_name}
                </td>
                <td>
                    {this.props.data.dealer_company_address}
                </td>
                <td>
                    {this.props.data.dealer_email+" && "+this.props.data.dealer_number}
                </td>
                <td>
                    {/* <Button onClick={this.editRecord()} className="btn btn-promary">EDIT</Button> */}
                    {this.editRecord(this.props.data.car_dealer_id)}
                </td>
                <td>
                    <Button onClick={(event)=>this.deleteDealerRecord(event)} className="btn btn-danger" value={this.props.data.car_dealer_id}>DELETE</Button>
                </td>
                </tr>
        )
    }
}

export default DealerList
